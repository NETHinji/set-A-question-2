﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SETA
{
    public static class Extension
    {
        public static int CountNumber(this string s)
        {
            int counter = 0, index = 0;
            var text = s.Trim();
            //for(int i = 0; i < s.Length; i++)
            //{
            //    counter++;
            //}
            while (index < s.Length)
            {
                // check if current char is part of a word
                while (index < text.Length && !char.IsWhiteSpace(text[index]))
                    index++;

                counter++;

                // skip whitespace until next word
                while (index < text.Length && char.IsWhiteSpace(text[index]))
                    index++;
            }
            return counter;
        }
    }
}
